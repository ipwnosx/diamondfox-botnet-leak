$(document).ready(function(){
	
	$('.pic a').lightBox({
		
		imageLoading: 'inc/lightbox/images/loading.gif',
		imageBtnClose: 'inc/lightbox/images/close.gif',
		imageBtnPrev: 'inc/lightbox/images/prev.gif',
		imageBtnNext: 'inc/lightbox/images/next.gif'

	});
	
});